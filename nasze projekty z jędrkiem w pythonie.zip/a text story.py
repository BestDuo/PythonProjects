import random
import time

# Initialize character stats
health = 100
strength = 10

# Define the story chapters
def chapter1():
    global health
    print("\n** Chapter 1: The Decision **")
    print("You are Arthur, a young man in the village of Oakridge.")
    print("You long for love and decide to become a knight.")
    input("Press Enter to continue...")
    print("\nYou start your journey as a squire, training to become a knight.")

def chapter2():
    global health, strength
    print("\n** Chapter 2: Training as a Squire **")
    print("As a squire, you must train hard to become a knight.")
    print("Your health is at", health)
    print("Your strength is at", strength)
    input("Press Enter to continue...")
    # Simulate training
    for _ in range(3):
        damage = random.randint(5, 15)
        print(f"\nYou endure a tough training session and lose {damage} health.")
        health -= damage
        print("Your health is now at", health)
        input("Press Enter to continue...")
    print("\nYou've completed your squire training and gained strength!")

def chapter3():
    global health
    print("\n** Chapter 3: The First Battle **")
    print("You accompany seasoned knights on a quest.")
    input("Press Enter to continue...")
    # Simulate a battle
    enemy_health = 50
    while enemy_health > 0:
        enemy_damage = random.randint(5, 15)
        player_damage = random.randint(5, 20)
        print(f"\nYou engage in battle with an enemy!")
        print(f"Enemy's health: {enemy_health}, Your health: {health}")
        print(f"You deal {player_damage} damage to the enemy.")
        enemy_health -= player_damage
        print(f"The enemy retaliates and deals {enemy_damage} damage to you.")
        health -= enemy_damage
        input("Press Enter to continue...")
    print("\nYou emerge victorious from the battle!")

def chapter4():
    global health
    print("\n** Chapter 4: Winning the Battle **")
    print("The villagers celebrate your victory as a hero.")
    input("Press Enter to continue...")
    print("\nDuring the grand feast, you meet a kind and beautiful maiden named Eleanor.")
    print("You fall in love, and your adventures have led you to true love.")

# Main game loop
while health > 0:
    chapter1()
    chapter2()
    chapter3()
    chapter4()
    break

# Game over
if health <= 0:
    print("\n** Game Over **")
    print("Your journey ended prematurely due to your injuries.")
else:
    print("\n** The End **")
    print("You lived happily ever after with your love, Eleanor.")
