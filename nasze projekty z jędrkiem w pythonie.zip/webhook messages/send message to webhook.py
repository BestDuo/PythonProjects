import tkinter as tk
import requests

# Function to send the message to the Discord webhook
def send_message():
    webhook_url = entry_url.get()
    message_content = entry_message.get()

    try:
        response = requests.post(webhook_url, json={"content": message_content})
        if response.status_code == 204:
            result_label.config(text="Message sent successfully!", fg="green")
        else:
            result_label.config(text="Failed to send message. Status code: " + str(response.status_code), fg="red")
    except Exception as e:
        result_label.config(text="Error: " + str(e), fg="red")

# Create the main window
root = tk.Tk()
root.title("Discord Webhook Sender")

# Define dark mode colors
bg_color = "#121212"  # Dark background color
fg_color = "#FFFFFF"  # White text color

# Set window background color
root.configure(bg=bg_color)

# Create and pack widgets with dark mode appearance
label_url = tk.Label(root, text="Webhook URL:", bg=bg_color, fg=fg_color)
label_url.pack(pady=10)

entry_url = tk.Entry(root, width=40)
entry_url.pack()

label_message = tk.Label(root, text="Message:", bg=bg_color, fg=fg_color)
label_message.pack(pady=10)

entry_message = tk.Entry(root, width=40)
entry_message.pack()

send_button = tk.Button(root, text="Send Message", command=send_message, bg="#1976D2", fg=fg_color)
send_button.pack(pady=20)

result_label = tk.Label(root, text="", fg=fg_color, bg=bg_color)
result_label.pack()

# Set a background image (you can replace 'background.png' with your image)
try:
    background_image = tk.PhotoImage(file='backgroud.png')
    background_label = tk.Label(root, image=background_image)
    background_label.place(relwidth=1, relheight=1)
    background_label.lower()
except Exception as e:
    print("Error loading background image:", e)

# Start the main loop
root.mainloop()
