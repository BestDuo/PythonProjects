import tkinter as tk
import random

class CookieClicker:
    def __init__(self, root):
        self.root = root
        self.root.title("Cookie Clicker")
        
        self.score = 0
        
        self.buttons = [
            ("Button 1", 1),
            ("Button 2", 2),
            ("Button 3", 3),
            ("Button 4", 4),
            ("Button 5", 5)
        ]
        
        for button_name, value in self.buttons:
            button = tk.Button(root, text=button_name, command=lambda value=value: self.click_cookie(value))
            button.pack(pady=5)
        
        self.score_label = tk.Label(root, text="Score: 0")
        self.score_label.pack()
        
    def click_cookie(self, value):
        self.score += value
        self.update_score()
    
    def update_score(self):
        self.score_label.config(text="Score: " + str(self.score))

if __name__ == "__main__":
    root = tk.Tk()
    app = CookieClicker(root)
    root.mainloop()
